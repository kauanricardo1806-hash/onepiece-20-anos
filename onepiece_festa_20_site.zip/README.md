# Festa One Piece — 20 anos

Site responsivo de convite e confirmação de presença, com painel administrativo e banco SQLite.

## Recursos
- Página pública temática com data, horário, local e mensagem configuráveis.
- Formulário de confirmação com nome, telefone opcional, acompanhantes e recado.
- Contador público de pessoas confirmadas.
- Painel protegido por login para editar o evento, consultar/remover convidados e exportar CSV.
- Banco SQLite persistente no servidor.

## Como executar
Requer Node.js 18 ou superior.

1. Extraia o ZIP.
2. Copie `.env.example` para `.env`.
3. Altere `ADMIN_USER`, `ADMIN_PASSWORD` e `SESSION_SECRET`.
4. No terminal, dentro da pasta do projeto, execute:
   ```bash
   npm install
   npm start
   ```
5. Abra `http://localhost:3000`.
6. Painel administrativo: `http://localhost:3000/admin.html`.

## Antes de publicar
- Configure variáveis de ambiente fortes no serviço de hospedagem.
- Use HTTPS (necessário para cookie seguro em produção).
- Configure backup do arquivo `festa.sqlite`.
- O projeto precisa ser hospedado em um servidor Node.js para que as confirmações sejam compartilhadas entre todos os convidados. Abrir o HTML diretamente não ativa a API.
- Para mudar o visual, edite `public/style.css`; para textos e estrutura, `public/index.html`.

## Segurança e privacidade
O login usa sessão e senha protegida por hash em memória no início do servidor. Defina credenciais próprias antes de publicar. Colete apenas dados necessários à organização da festa e restrinja o acesso à lista de convidados.

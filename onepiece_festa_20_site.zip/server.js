require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database("festa.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS event (
 id INTEGER PRIMARY KEY CHECK (id=1), title TEXT NOT NULL, date TEXT DEFAULT '',
 time TEXT DEFAULT '', location TEXT DEFAULT '', address TEXT DEFAULT '',
 message TEXT DEFAULT '', updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS guests (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '',
 companions INTEGER NOT NULL DEFAULT 0, note TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);
const existing = db.prepare("SELECT id FROM event WHERE id=1").get();
if (!existing) db.prepare("INSERT INTO event (id,title,message) VALUES (1,?,?)").run("A grande aventura dos 20 anos", "Sua presença vai tornar essa aventura ainda mais especial!");
const ADMIN_USER = process.env.ADMIN_USER || "capitao";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "mude-esta-senha";
const passwordHash = bcrypt.hashSync(ADMIN_PASSWORD, 10);

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"20kb"}));
app.use(session({
 secret:process.env.SESSION_SECRET || "desenvolvimento-troque-esta-chave",
 resave:false, saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000}
}));
const loginLimiter = rateLimit({windowMs:15*60*1000,limit:8,standardHeaders:true,legacyHeaders:false});
const admin = (req,res,next)=>req.session && req.session.isAdmin ? next() : res.status(401).json({error:"Faça login para continuar."});

app.use(express.static(path.join(__dirname,"public")));
app.get("/api/event",(req,res)=>res.json(db.prepare("SELECT title,date,time,location,address,message FROM event WHERE id=1").get()));
app.get("/api/stats",(req,res)=>{
 const row=db.prepare("SELECT COUNT(*) AS guests, COALESCE(SUM(companions),0) AS companions FROM guests").get();
 res.json({guests:row.guests,companions:row.companions,total:row.guests+row.companions});
});
app.post("/api/rsvp",(req,res)=>{
 const name=String(req.body.name||"").trim().slice(0,90);
 const phone=String(req.body.phone||"").trim().slice(0,30);
 const companions=Number(req.body.companions||0);
 const note=String(req.body.note||"").trim().slice(0,240);
 if(name.length<2) return res.status(400).json({error:"Informe seu nome completo."});
 if(!Number.isInteger(companions)||companions<0||companions>10) return res.status(400).json({error:"Quantidade de acompanhantes inválida."});
 db.prepare("INSERT INTO guests (name,phone,companions,note) VALUES (?,?,?,?)").run(name,phone,companions,note);
 res.json({ok:true,message:"Presença confirmada! Sua aventura está garantida."});
});
app.post("/api/admin/login",loginLimiter,(req,res)=>{
 const user=String(req.body.username||"");
 const pass=String(req.body.password||"");
 if(user!==ADMIN_USER || !bcrypt.compareSync(pass,passwordHash)) return res.status(401).json({error:"Usuário ou senha incorretos."});
 req.session.isAdmin=true;
 res.json({ok:true});
});
app.post("/api/admin/logout",admin,(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/admin/me",(req,res)=>res.json({authenticated:!!(req.session&&req.session.isAdmin)}));
app.put("/api/admin/event",admin,(req,res)=>{
 const clean=(v,n=180)=>String(v||"").trim().slice(0,n);
 db.prepare(`UPDATE event SET title=?,date=?,time=?,location=?,address=?,message=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`)
 .run(clean(req.body.title,100),clean(req.body.date,30),clean(req.body.time,20),clean(req.body.location,100),clean(req.body.address,220),clean(req.body.message,240));
 res.json({ok:true});
});
app.get("/api/admin/guests",admin,(req,res)=>{
 res.json(db.prepare("SELECT id,name,phone,companions,note,created_at FROM guests ORDER BY created_at DESC,id DESC").all());
});
app.delete("/api/admin/guests/:id",admin,(req,res)=>{
 const result=db.prepare("DELETE FROM guests WHERE id=?").run(Number(req.params.id));
 res.json({ok:result.changes>0});
});
app.get("/api/admin/export",admin,(req,res)=>{
 const rows=db.prepare("SELECT name,phone,companions,note,created_at FROM guests ORDER BY name").all();
 const esc=v=>'"'+String(v??"").replace(/"/g,'""')+'"';
 const csv=["Nome,Telefone,Acompanhantes,Observação,Confirmado em",...rows.map(r=>[r.name,r.phone,r.companions,r.note,r.created_at].map(esc).join(","))].join("\n");
 res.setHeader("Content-Type","text/csv; charset=utf-8");
 res.setHeader("Content-Disposition",'attachment; filename="lista-de-presenca.csv"');
 res.send("\uFEFF"+csv);
});
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`Festa One Piece rodando em http://localhost:${port}`));
